"""Elimineer spelers"""

__version__ = '0.3'

from pymol_app._molfuncs import interpolate_color, pulse_screen